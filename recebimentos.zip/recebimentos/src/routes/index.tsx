import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState, type ReactNode } from "react";
import {
  Bar, BarChart, CartesianGrid, Cell, Line, ComposedChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import * as XLSX from "xlsx";
import seed from "@/data/recebimentos.json";
import {
  MESES, applyFilters, brl, brl2, fromSheet, groupSum, kpis, num, quality, type Filters, type Rec,
} from "@/lib/recebimentos";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Painel de Recebimentos — Compras e Fornecedores" },
      { name: "description", content: "Dashboard interativo de recebimentos: valores por mês, fornecedor, projeto e item." },
      { property: "og:title", content: "Painel de Recebimentos" },
      { property: "og:description", content: "Indicadores de recebimentos por mês, fornecedor e projeto." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
    links: [
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,700&family=IBM+Plex+Sans:wght@400;500;600&display=swap" },
    ],
  }),
  component: Dashboard,
});

const empty: Filters = { meses: [], forn: "", proj: "", dep: "", q: "" };
const C = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];

function Dashboard() {
  const [data, setData] = useState<Rec[]>(seed as Rec[]);
  const [source, setSource] = useState("Recebimentos_feitos.xlsx");
  const [f, setF] = useState<Filters>(empty);
  const [page, setPage] = useState(0);
  const [err, setErr] = useState("");

  const rows = useMemo(() => applyFilters(data, f), [data, f]);
  const k = useMemo(() => kpis(rows), [rows]);
  const q = useMemo(() => quality(data), [data]);
  const porMes = useMemo(() => {
    const g = new Map(groupSum(rows, (r) => r.mes).map((x) => [x.key, x]));
    const meses = [...new Set(data.map((r) => r.mes))].sort((a, b) => a - b);
    let acc = 0;
    return meses.map((m) => {
      const t = g.get(m)?.total ?? 0; acc += t;
      return { mes: MESES[m - 1] ?? String(m), m, total: t, acumulado: acc, linhas: g.get(m)?.linhas ?? 0 };
    });
  }, [rows, data]);
  const topForn = useMemo(() => groupSum(rows, (r) => r.nome).slice(0, 10), [rows]);
  const topProj = useMemo(() => groupSum(rows, (r) => r.proj ?? "(sem projeto)").slice(0, 10), [rows]);
  const porDep = useMemo(() => groupSum(rows, (r) => r.dep), [rows]);
  const topItens = useMemo(() => {
    const m = new Map<string, { desc: string; total: number; qtd: number }>();
    for (const r of rows) {
      const g = m.get(r.item) ?? { desc: r.desc, total: 0, qtd: 0 };
      g.total += r.total; g.qtd += r.qtd; m.set(r.item, g);
    }
    return [...m.entries()].sort((a, b) => b[1].total - a[1].total).slice(0, 8);
  }, [rows]);

  const opts = useMemo(() => ({
    forn: [...new Set(data.map((r) => r.nome))].sort(),
    proj: [...new Set(data.map((r) => r.proj ?? "(sem projeto)"))].sort(),
    dep: [...new Set(data.map((r) => r.dep))].sort(),
    meses: [...new Set(data.map((r) => r.mes))].sort((a, b) => a - b),
  }), [data]);

  const best = [...porMes].sort((a, b) => b.total - a.total)[0];
  const set = (p: Partial<Filters>) => { setF({ ...f, ...p }); setPage(0); };
  const toggleMes = (m: number) => set({ meses: f.meses.includes(m) ? f.meses.filter((x) => x !== m) : [...f.meses, m] });

  async function upload(file: File) {
    try {
      const wb = XLSX.read(await file.arrayBuffer());
      const parsed = fromSheet(XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0] ?? ""]!));
      if (!parsed.length) throw new Error("Nenhuma linha reconhecida. Os cabeçalhos devem seguir o modelo original.");
      setData(parsed); setSource(file.name); setF(empty); setErr("");
    } catch (e) { setErr((e as Error).message); }
  }

  function exportar() {
    const ws = XLSX.utils.json_to_sheet(rows.map((r) => ({
      "Nº Recebimento": r.rec, Mês: r.mes, Fornecedor: r.forn, "Nome Fornecedor": r.nome, Item: r.item,
      Descrição: r.desc, Quantidade: r.qtd, "Custo Unitário R$": r.unit, "Total R$": r.total, Depósito: r.dep, Projeto: r.proj,
    })));
    const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, "Filtrado");
    XLSX.writeFile(wb, "recebimentos_filtrados.xlsx");
  }

  const PER = 15;
  const pageRows = rows.slice(page * PER, page * PER + PER);
  const pages = Math.max(1, Math.ceil(rows.length / PER));

  return (
    <div className="min-h-screen">
      <header className="bg-sidebar text-sidebar-foreground">
        <div className="mx-auto flex max-w-7xl flex-wrap items-end justify-between gap-4 px-6 py-8">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-sidebar-primary">Compras · Recebimentos</p>
            <h1 className="font-display text-4xl font-bold">Painel de Recebimentos</h1>
            <p className="mt-1 text-sm opacity-70">Fonte: {source} · {data.length.toLocaleString("pt-BR")} linhas</p>
          </div>
          <div className="flex gap-2">
            <label className="cursor-pointer rounded-md bg-sidebar-primary px-4 py-2 text-sm font-semibold text-sidebar-primary-foreground hover:opacity-90">
              Carregar nova planilha
              <input type="file" accept=".xlsx,.xls,.xlsm" className="hidden" onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])} />
            </label>
            <button onClick={exportar} className="rounded-md border border-sidebar-border px-4 py-2 text-sm hover:bg-sidebar-accent">Exportar filtrado</button>
          </div>
        </div>
        {err && <p className="mx-auto max-w-7xl px-6 pb-4 text-sm text-destructive">{err}</p>}
      </header>

      <main className="mx-auto max-w-7xl space-y-6 px-6 py-6">
        {/* Filtros */}
        <section className="space-y-3 rounded-lg border bg-card p-4">
          <div className="flex flex-wrap gap-1.5">
            {opts.meses.map((m) => (
              <button key={m} onClick={() => toggleMes(m)}
                className={`rounded-full px-3 py-1 text-xs font-medium transition ${f.meses.includes(m) ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground hover:bg-secondary"}`}>
                {MESES[m - 1] ?? m}
              </button>
            ))}
          </div>
          <div className="grid gap-2 md:grid-cols-5">
            <input value={f.q} onChange={(e) => set({ q: e.target.value })} placeholder="Buscar item, descrição, nº…" className="rounded-md border bg-background px-3 py-2 text-sm md:col-span-2" />
            <Sel v={f.forn} on={(v) => set({ forn: v })} all="Todos fornecedores" o={opts.forn} />
            <Sel v={f.proj} on={(v) => set({ proj: v })} all="Todos projetos" o={opts.proj} />
            <div className="flex gap-2">
              <Sel v={f.dep} on={(v) => set({ dep: v })} all="Todos depósitos" o={opts.dep} />
              <button onClick={() => set(empty)} className="rounded-md px-3 text-sm text-muted-foreground hover:bg-muted">Limpar</button>
            </div>
          </div>
        </section>

        {/* KPIs */}
        <section className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
          <Kpi label="Valor recebido" v={brl(k.total)} main />
          <Kpi label="Recebimentos" v={k.recebimentos.toLocaleString("pt-BR")} />
          <Kpi label="Linhas" v={k.linhas.toLocaleString("pt-BR")} />
          <Kpi label="Fornecedores" v={String(k.fornecedores)} />
          <Kpi label="Itens distintos" v={k.itens.toLocaleString("pt-BR")} />
          <Kpi label="Ticket médio / receb." v={brl(k.ticket)} />
        </section>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card title="Evolução mensal" sub="Clique numa barra para filtrar o mês" className="lg:col-span-2">
            <ResponsiveContainer width="100%" height={280}>
              <ComposedChart data={porMes}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="mes" fontSize={12} />
                <YAxis yAxisId="a" fontSize={11} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                <YAxis yAxisId="b" orientation="right" fontSize={11} tickFormatter={(v) => `${(v / 1e6).toFixed(1)}M`} />
                <Tooltip formatter={(v: number) => brl(v)} />
                <Bar yAxisId="a" dataKey="total" name="Mês" fill="var(--chart-1)" radius={[4, 4, 0, 0]} onClick={(d: { m?: number }) => d.m && toggleMes(d.m)} cursor="pointer" />
                <Line yAxisId="b" dataKey="acumulado" name="Acumulado" stroke="var(--chart-2)" strokeWidth={2} dot={false} />
              </ComposedChart>
            </ResponsiveContainer>
          </Card>
          <Card title="Por depósito">
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={porDep} dataKey="total" nameKey="key" innerRadius={50} outerRadius={85} onClick={(d: { key?: string }) => d.key && set({ dep: f.dep === d.key ? "" : d.key })} cursor="pointer">
                  {porDep.map((_, i) => <Cell key={i} fill={C[i % C.length]} />)}
                </Pie>
                <Tooltip formatter={(v: number) => brl(v)} />
              </PieChart>
            </ResponsiveContainer>
            <ul className="mt-2 space-y-1 text-sm">
              {porDep.map((d, i) => (
                <li key={d.key} className="flex justify-between"><span className="flex items-center gap-2"><i className="size-2.5 rounded-full" style={{ background: C[i % C.length] }} />Depósito {d.key}</span><span className="tabular">{k.total ? ((d.total / k.total) * 100).toFixed(1) : 0}%</span></li>
              ))}
            </ul>
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card title="Top 10 fornecedores" sub="Clique para filtrar">
            <HBar data={topForn} onPick={(v) => set({ forn: f.forn === v ? "" : v })} color="var(--chart-1)" />
          </Card>
          <Card title="Top 10 projetos" sub="Clique para filtrar">
            <HBar data={topProj} onPick={(v) => set({ proj: f.proj === v ? "" : v })} color="var(--chart-3)" />
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card title="Itens de maior valor" className="lg:col-span-2">
            <table className="w-full text-sm">
              <tbody>
                {topItens.map(([id, g]) => (
                  <tr key={id} className="border-b last:border-0">
                    <td className="py-2 pr-2"><div className="line-clamp-1 font-medium">{g.desc}</div><div className="text-xs text-muted-foreground">{id} · qtd {num(g.qtd)}</div></td>
                    <td className="tabular py-2 text-right font-semibold">{brl(g.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
          <Card title="Destaques e qualidade dos dados" sub="Calculado sobre a planilha inteira">
            <ul className="space-y-2.5 text-sm">
              {best && <Note>Mês de maior volume no filtro: <b>{best.mes}</b> ({brl(best.total)}).</Note>}
              <Note>Os 5 maiores fornecedores concentram <b>{(q.concentracaoTop5 * 100).toFixed(1)}%</b> do valor total.</Note>
              <Note warn={q.semProjeto > 0}><b>{q.semProjeto}</b> linhas sem projeto informado.</Note>
              <Note warn={q.semMoeda > 0}><b>{q.semMoeda}</b> linhas sem moeda informada.</Note>
              <Note warn={q.valorZero > 0}><b>{q.valorZero}</b> linhas com valor total zero ou negativo.</Note>
              <Note warn={q.duplicados > 0}><b>{q.duplicados}</b> linhas possivelmente duplicadas (mesmo recebimento, item, quantidade e valor).</Note>
              <Note warn={q.calcDivergente > 0}><b>{q.calcDivergente}</b> linhas onde quantidade × custo unitário não confere com o total.</Note>
            </ul>
          </Card>
        </div>

        <Card title={`Registros de origem (${rows.length.toLocaleString("pt-BR")})`} sub={`Soma: ${brl2(k.total)}`}>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-left text-xs uppercase text-muted-foreground">
                <tr>{["#", "Receb.", "Mês", "Fornecedor", "Descrição", "Qtd", "Unit. R$", "Total R$", "Dep.", "Projeto"].map((h) => <th key={h} className="px-2 py-2 font-medium">{h}</th>)}</tr>
              </thead>
              <tbody className="tabular">
                {pageRows.map((r) => (
                  <tr key={r.id} className="border-t hover:bg-muted/60">
                    <td className="px-2 py-1.5 text-muted-foreground">{r.id}</td>
                    <td className="px-2">{r.rec}</td>
                    <td className="px-2">{MESES[r.mes - 1]}</td>
                    <td className="max-w-40 truncate px-2">{r.nome}</td>
                    <td className="max-w-72 truncate px-2" title={r.desc}>{r.desc}</td>
                    <td className="px-2 text-right">{num(r.qtd)}</td>
                    <td className="px-2 text-right">{brl2(r.unit)}</td>
                    <td className="px-2 text-right font-medium">{brl2(r.total)}</td>
                    <td className="px-2">{r.dep}</td>
                    <td className="px-2">{r.proj ?? <span className="text-destructive">—</span>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-3 flex items-center justify-end gap-2 text-sm">
            <button disabled={page === 0} onClick={() => setPage(page - 1)} className="rounded border px-3 py-1 disabled:opacity-40">Anterior</button>
            <span className="text-muted-foreground">{page + 1} / {pages}</span>
            <button disabled={page >= pages - 1} onClick={() => setPage(page + 1)} className="rounded border px-3 py-1 disabled:opacity-40">Próxima</button>
          </div>
        </Card>
      </main>
    </div>
  );
}

function Sel({ v, on, all, o }: { v: string; on: (v: string) => void; all: string; o: string[] }) {
  return (
    <select value={v} onChange={(e) => on(e.target.value)} className="w-full min-w-0 rounded-md border bg-background px-2 py-2 text-sm">
      <option value="">{all}</option>
      {o.map((x) => <option key={x} value={x}>{x}</option>)}
    </select>
  );
}

function Kpi({ label, v, main }: { label: string; v: string; main?: boolean }) {
  return (
    <div className={`rounded-lg border p-4 ${main ? "bg-primary text-primary-foreground" : "bg-card"}`}>
      <p className={`text-xs uppercase tracking-wide ${main ? "opacity-80" : "text-muted-foreground"}`}>{label}</p>
      <p className="tabular mt-1 font-display text-2xl font-bold">{v}</p>
    </div>
  );
}

function Card({ title, sub, children, className = "" }: { title: string; sub?: string; children: ReactNode; className?: string }) {
  return (
    <section className={`rounded-lg border bg-card p-5 ${className}`}>
      <div className="mb-3 flex items-baseline justify-between gap-2">
        <h2 className="font-display text-lg font-semibold">{title}</h2>
        {sub && <span className="text-xs text-muted-foreground">{sub}</span>}
      </div>
      {children}
    </section>
  );
}

function HBar({ data, onPick, color }: { data: { key: string; total: number }[]; onPick: (v: string) => void; color: string }) {
  return (
    <ResponsiveContainer width="100%" height={320}>
      <BarChart data={data} layout="vertical" margin={{ left: 10 }}>
        <XAxis type="number" fontSize={11} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
        <YAxis type="category" dataKey="key" width={150} fontSize={10} tickFormatter={(v: string) => (v.length > 22 ? v.slice(0, 22) + "…" : v)} />
        <Tooltip formatter={(v: number) => brl(v)} />
        <Bar dataKey="total" fill={color} radius={[0, 4, 4, 0]} cursor="pointer" onClick={(d: { key?: string }) => d.key && onPick(d.key)} />
      </BarChart>
    </ResponsiveContainer>
  );
}

function Note({ children, warn }: { children: ReactNode; warn?: boolean }) {
  return (
    <li className="flex gap-2">
      <span className={`mt-1.5 size-2 shrink-0 rounded-full ${warn ? "bg-accent" : "bg-primary"}`} />
      <span>{children}</span>
    </li>
  );
}
