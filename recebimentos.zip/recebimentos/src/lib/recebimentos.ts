export type Rec = {
  id: number; rec: number; mes: number; forn: string; nome: string; item: string; desc: string;
  qtd: number; unit: number; total: number; moeda: string | null; dep: string; proj: string | null;
};

export const MESES = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];

export const brl = (v: number) =>
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });
export const brl2 = (v: number) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
export const num = (v: number) => v.toLocaleString("pt-BR", { maximumFractionDigits: 2 });

/** Converts sheet rows (array of objects keyed by header) to records. */
export function fromSheet(rows: Record<string, unknown>[]): Rec[] {
  const n = (v: unknown) => (typeof v === "number" ? v : Number(String(v ?? "").replace(",", ".")) || 0);
  const s = (v: unknown) => (v == null || v === "" ? null : String(v).trim());
  return rows
    .filter((r) => r["Nº Recebimento"] != null)
    .map((r, i) => ({
      id: n(r["#"]) || i + 1,
      rec: n(r["Nº Recebimento"]),
      mes: n(r["Mês"]),
      forn: s(r["Fornecedor"]) ?? "",
      nome: s(r["Nome Fornecedor"]) ?? "",
      item: s(r["Item"]) ?? "",
      desc: s(r["Descrição"]) ?? "",
      qtd: n(r["Quantidade"]),
      unit: n(r["Custo Unitário R$"]),
      total: n(r["Total R$"]),
      moeda: s(r["Moeda"]),
      dep: s(r["Depósito"]) ?? "",
      proj: s(r["Projeto"]),
    }));
}

export type Filters = { meses: number[]; forn: string; proj: string; dep: string; q: string };

export function applyFilters(data: Rec[], f: Filters) {
  const q = f.q.trim().toLowerCase();
  return data.filter(
    (r) =>
      (f.meses.length === 0 || f.meses.includes(r.mes)) &&
      (!f.forn || r.nome === f.forn) &&
      (!f.proj || (r.proj ?? "(sem projeto)") === f.proj) &&
      (!f.dep || r.dep === f.dep) &&
      (!q || `${r.desc} ${r.item} ${r.nome} ${r.rec} ${r.proj ?? ""}`.toLowerCase().includes(q)),
  );
}

export function groupSum<K extends string | number>(data: Rec[], key: (r: Rec) => K) {
  const m = new Map<K, { key: K; total: number; linhas: number }>();
  for (const r of data) {
    const k = key(r);
    const g = m.get(k) ?? { key: k, total: 0, linhas: 0 };
    g.total += r.total; g.linhas++;
    m.set(k, g);
  }
  return [...m.values()].sort((a, b) => b.total - a.total);
}

export function kpis(data: Rec[]) {
  const total = data.reduce((a, r) => a + r.total, 0);
  const recs = new Set(data.map((r) => r.rec)).size;
  return {
    total, linhas: data.length, recebimentos: recs,
    fornecedores: new Set(data.map((r) => r.nome)).size,
    itens: new Set(data.map((r) => r.item)).size,
    ticket: recs ? total / recs : 0,
  };
}

export function quality(data: Rec[]) {
  const seen = new Map<string, number>();
  for (const r of data) {
    const k = `${r.rec}|${r.item}|${r.qtd}|${r.total}`;
    seen.set(k, (seen.get(k) ?? 0) + 1);
  }
  const top5 = groupSum(data, (r) => r.nome).slice(0, 5).reduce((a, g) => a + g.total, 0);
  const total = data.reduce((a, r) => a + r.total, 0);
  return {
    semProjeto: data.filter((r) => !r.proj).length,
    semMoeda: data.filter((r) => !r.moeda).length,
    valorZero: data.filter((r) => r.total <= 0).length,
    duplicados: [...seen.values()].reduce((a, c) => a + (c > 1 ? c - 1 : 0), 0),
    calcDivergente: data.filter((r) => Math.abs(r.qtd * r.unit - r.total) > Math.max(1, r.total * 0.01)).length,
    concentracaoTop5: total ? top5 / total : 0,
  };
}
